package ams1_uf3_ficheros_binarios_david_artero;

public class ficheros_binarios_prueba1 {

	public static void main(String[] args) {

	
	}

}
