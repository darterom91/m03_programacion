
public class practica5 {
	public static void main(String[] args) {
		String frase="Hola amigo como esta?";
		String frases[]=frase.split(" ");
		
		System.out.println("Cantidad de palabras: "+frase.length());
		System.out.println("La cantidad de palabras es: "+frases.length);


		
	}
}
