package Examen;

import java.util.Scanner;

//Practica4 Ej [1] Pregunta examen: 1
//Practica1 Ej [2] Pregunta examen: 2
//Practica1 Ej [2] Pregunta examen: 3
//Practica5 Ej [7] Pregunta examen: 4
//Practica5 Ej [4] Pregunta examen: 5
//Practica1 Ej [1] Pregunta examen: 6
public class Ejercicio1 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
