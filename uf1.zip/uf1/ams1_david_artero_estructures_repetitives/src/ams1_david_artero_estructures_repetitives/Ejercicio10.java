package ams1_david_artero_estructures_repetitives;

public class Ejercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;

		for (i = 1; i <= 10; i++) {
			System.out.print(i + " ");
		}
		System.out.println();
		for (i = 2; i <= 20; i = i + 2) {
			System.out.print(i + " ");
		}
		System.out.println();
		for (i = 20; i <= 28; i = i + 2) {
			System.out.print(i + " ");
		}
		System.out.println();
		for (i = 10; i <= 30; i = i + 4) {
			System.out.print(i + " ");
		}
		System.out.println();
		for (i = 40; i >= 0; i = i - 5) {
			System.out.print(i + " ");
		}
	}

}
